// app.jsx — shell, navigation, audit store, tweaks. Mounts to #root.
const { useState: useStateApp, useEffect: useEffectApp } = React;

const ACCENTS = [
  { hex: '#2f6bf0', hue: 255 }, // solar blue (default)
  { hex: '#0e87b4', hue: 218 }, // azure
  { hex: '#15998c', hue: 186 }, // teal
  { hex: '#7a5ae0', hue: 292 }, // violet
  { hex: '#e08a1e', hue: 70  }, // sun amber
];
const FONTS = {
  grotesk: { display: "'Space Grotesk', sans-serif", ui: "'Plus Jakarta Sans', sans-serif" },
  jakarta: { display: "'Plus Jakarta Sans', sans-serif", ui: "'Plus Jakarta Sans', sans-serif" },
};

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#2f6bf0",
  "headingFont": "grotesk",
  "threshold": 80,
  "density": "regular",
  "dark": false
}/*EDITMODE-END*/;

const ICONS = {
  summary: <g fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M3.5 16.5V8 M8 16.5V4 M12.5 16.5v-5 M3 16.5h13" /><circle cx="14.5" cy="6.5" r="2.2" /></g>,
  audit: <path d="M4 4.5A1.5 1.5 0 015.5 3H11l5 5v8.5A1.5 1.5 0 0114.5 18h-9A1.5 1.5 0 014 16.5v-12z M11 3v5h5 M7.5 11.5l1.6 1.6L13 9.5" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />,
  analytics: <path d="M4 16V9 M9 16V5 M14 16v-4 M3 16.5h13" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />,
  performance: <g fill="none" stroke="currentColor" strokeWidth="1.5"><circle cx="10" cy="7.5" r="3.2" /><path d="M4.5 16.5c0-3 2.6-4.7 5.5-4.7s5.5 1.7 5.5 4.7" strokeLinecap="round" /></g>,
};

const NAV = [
  { key: 'summary', label: 'Summary', desc: 'City & TL overview' },
  { key: 'audit', label: 'New Audit', desc: 'Score a call' },
  { key: 'analytics', label: 'Analytics', desc: 'Team reporting' },
  { key: 'performance', label: 'My Performance', desc: 'LRM scorecard' },
];

function Sidebar({ active, onNav, count, session }) {
  const who = (session && session.name) || 'Signed in';
  const role = (session && session.role) || 'Team Lead';
  return (
    <aside className="ss-sidebar" style={{
      width: 252, flex: '0 0 252px', background: 'var(--surface)', borderRight: '1px solid var(--line)',
      display: 'flex', flexDirection: 'column', height: '100%',
    }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 9, padding: '20px 20px 20px' }}>
        <img src="/solarsquare-logo.png" alt="SolarSquare" style={{ width: 124, height: 'auto', display: 'block' }} />
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ width: 18, height: 2, borderRadius: 2, background: 'var(--primary)', flex: '0 0 auto' }} />
          <span style={{ fontSize: 11, color: 'var(--ink-2)', fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase' }}>Quality Systems</span>
        </div>
      </div>

      <nav className="ss-nav" style={{ display: 'flex', flexDirection: 'column', gap: 4, padding: '0 12px', flex: 1 }}>
        {NAV.map(n => {
          const on = active === n.key;
          return (
            <button key={n.key} onClick={() => onNav(n.key)} style={{
              display: 'flex', alignItems: 'center', gap: 12, padding: '10px 12px', borderRadius: 'var(--radius-sm)',
              border: 'none', background: on ? 'var(--primary-soft)' : 'transparent', textAlign: 'left',
              color: on ? 'var(--primary-strong)' : 'var(--ink-2)', transition: 'background 0.15s, color 0.15s', width: '100%',
            }}
              onMouseEnter={e => { if (!on) e.currentTarget.style.background = 'var(--surface-2)'; }}
              onMouseLeave={e => { if (!on) e.currentTarget.style.background = 'transparent'; }}>
              <svg width="20" height="20" viewBox="0 0 20 20" style={{ flex: '0 0 auto', color: on ? 'var(--primary)' : 'var(--ink-3)' }}>{ICONS[n.key]}</svg>
              <span style={{ flex: 1 }}>
                <span style={{ display: 'block', fontSize: 13.5, fontWeight: 600, lineHeight: 1.2 }}>{n.label}</span>
                <span style={{ display: 'block', fontSize: 11.5, color: 'var(--ink-3)', fontWeight: 500 }}>{n.desc}</span>
              </span>
              {n.key === 'analytics' && <Badge tone={on ? 'primary' : 'neutral'} mono>{count}</Badge>}
            </button>
          );
        })}
      </nav>

      <div className="ss-userbox" style={{ padding: 14, margin: 12, borderRadius: 'var(--radius-sm)', background: 'var(--surface-2)', border: '1px solid var(--line-soft)', display: 'flex', alignItems: 'center', gap: 11 }}>
        <Avatar name={who} size={34} />
        <div style={{ minWidth: 0, flex: 1 }}>
          <div style={{ fontSize: 12.5, fontWeight: 600, color: 'var(--ink)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{who}</div>
          <div style={{ fontSize: 11, color: 'var(--ink-3)' }}>{role}</div>
        </div>
        <span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--ok)', flex: '0 0 auto' }} title="Online" />
      </div>
    </aside>
  );
}

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [active, setActive] = useStateApp('summary');
  const [audits, setAudits] = useStateApp([]);
  const [meetings, setMeetings] = useStateApp([]);
  const [agents, setAgents] = useStateApp([]);
  const [session, setSession] = useStateApp({ name: '', email: '' });
  const [loading, setLoading] = useStateApp(true);
  const [busy, setBusy] = useStateApp(false);

  // initial load — live Sheet data in Apps Script, mock data in preview
  useEffectApp(() => {
    let alive = true;
    (async () => {
      const api = window.QA.api;
      const [user, emps, list, mtg] = await Promise.all([
        api.getCurrentUser(), api.getAllEmployees(), api.loadAudits(), api.loadMeetings(),
      ]);
      if (!alive) return;
      setSession(user); setAgents(emps); setAudits(list); setMeetings(mtg); setLoading(false);
    })().catch(err => { console.error(err); setLoading(false); });
    return () => { alive = false; };
  }, []);

  const reload = async () => { setAudits(await window.QA.api.loadAudits()); };

  const hue = (ACCENTS.find(a => a.hex === t.accent) || ACCENTS[0]).hue;
  const fonts = FONTS[t.headingFont] || FONTS.grotesk;

  useEffectApp(() => {
    const r = document.documentElement;
    r.style.setProperty('--accent-h', hue);
    r.style.setProperty('--font-display', fonts.display);
    r.style.setProperty('--font-ui', fonts.ui);
    r.setAttribute('data-density', t.density);
    r.setAttribute('data-theme', t.dark ? 'dark' : 'light');
  }, [hue, fonts.display, fonts.ui, t.density, t.dark]);

  const submitAudit = async (payload) => {
    setBusy(true);
    const res = await window.QA.api.saveAudit(payload);
    await reload(); setBusy(false);
    return res;
  };

  if (loading) return <BootSplash />;

  return (
    <div style={{ display: 'flex', height: '100%', minHeight: 0 }} className="ss-shell">
      <Sidebar active={active} onNav={setActive} count={audits.length} session={session} />
      <main className="ss-main" style={{ flex: 1, minWidth: 0, overflowY: 'auto', height: '100%' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', padding: '34px clamp(20px, 4vw, 44px) 80px' }}>
          {active === 'summary' && <SummaryView audits={audits} meetings={meetings} threshold={t.threshold} />}
          {active === 'audit' && <AuditView agents={agents} meetings={meetings} audits={audits} onSubmit={submitAudit} threshold={t.threshold} session={session} busy={busy} />}
          {active === 'analytics' && <AnalyticsView audits={audits} threshold={t.threshold} />}
          {active === 'performance' && <PerformanceView audits={audits} agents={agents} threshold={t.threshold} />}
        </div>
      </main>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Brand" />
        <TweakColor label="Accent" value={t.accent} options={ACCENTS.map(a => a.hex)} onChange={v => setTweak('accent', v)} />
        <TweakRadio label="Headings" value={t.headingFont} options={[{ value: 'grotesk', label: 'Grotesk' }, { value: 'jakarta', label: 'Jakarta' }]} onChange={v => setTweak('headingFont', v)} />
        <TweakSection label="Scoring" />
        <TweakSlider label="Pass threshold" value={t.threshold} min={50} max={95} step={5} unit="%" onChange={v => setTweak('threshold', v)} />
        <TweakSection label="Display" />
        <TweakRadio label="Density" value={t.density} options={['compact', 'regular', 'comfy']} onChange={v => setTweak('density', v)} />
        <TweakToggle label="Dark mode" value={t.dark} onChange={v => setTweak('dark', v)} />
      </TweaksPanel>

      <style>{RESPONSIVE_CSS}</style>
    </div>
  );
}

const RESPONSIVE_CSS = `
  @media (max-width: 1080px) {
    .audit-grid { grid-template-columns: 1fr !important; }
    .audit-rail { position: static !important; }
    .filter-trend-grid { grid-template-columns: 1fr !important; }
  }
  @media (max-width: 880px) {
    .kpi-grid { grid-template-columns: repeat(2, 1fr) !important; }
    .filter-grid { grid-template-columns: repeat(2, 1fr) !important; }
    .perf-grid { grid-template-columns: 1fr !important; }
    .miss-grid { grid-template-columns: 1fr !important; }
    .profile-grid { grid-template-columns: repeat(2, 1fr) !important; }
  }
  @media (max-width: 760px) {
    .ss-shell { flex-direction: column; }
    .ss-sidebar { width: 100% !important; flex: none !important; height: auto !important; border-right: none; border-bottom: 1px solid var(--line); }
    .ss-nav { flex-direction: row !important; overflow-x: auto; padding: 0 12px 12px !important; }
    .ss-nav button span span:last-child { display: none !important; }
    .ss-userbox { display: none !important; }
    .ss-main { height: auto !important; }
  }
  @media (max-width: 560px) {
    .kpi-grid { grid-template-columns: 1fr !important; }
    .profile-grid { grid-template-columns: 1fr !important; }
    .filter-grid { grid-template-columns: 1fr !important; }
  }
`;

function BootSplash() {
  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 16, background: 'var(--bg)' }}>
      <div style={{ width: 44, height: 44, borderRadius: 13, background: 'var(--primary)', position: 'relative', boxShadow: 'var(--shadow-md)' }}>
        <div style={{ position: 'absolute', top: 10, left: 10, width: 16, height: 16, borderRadius: '50%', background: 'var(--sun)' }} />
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 9, color: 'var(--ink-3)', fontSize: 13.5, fontWeight: 500 }}>
        <span style={{ width: 15, height: 15, border: '2px solid var(--line)', borderTopColor: 'var(--primary)', borderRadius: '50%', display: 'inline-block', animation: 'ss-spin 0.7s linear infinite' }} />
        Loading quality data…
      </div>
      <style>{`@keyframes ss-spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
