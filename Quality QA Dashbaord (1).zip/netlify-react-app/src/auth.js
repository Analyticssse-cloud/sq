// auth.js — optional Google Sign-In that auto-detects the auditor's email.
// It activates ONLY when VITE_GOOGLE_CLIENT_ID is set at build time. With no client id,
// this is a no-op and the audit form falls back to the manual-email field (still works).
//
// On success it stores { name, email, token } in localStorage under "qa_auth" and reloads,
// so app.jsx picks up the signed-in session via api.getCurrentUser(). The raw ID token is
// sent with each audit so the backend can verify the auditor server-side.

const CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID;
const ALLOWED_DOMAIN = import.meta.env.VITE_ALLOWED_DOMAIN || 'solarsquare.in';

function decodeJwt(token) {
  try {
    const b = token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
    return JSON.parse(decodeURIComponent(escape(atob(b))));
  } catch (e) { return {}; }
}

function readAuth() {
  try { return JSON.parse(localStorage.getItem('qa_auth') || 'null'); } catch (e) { return null; }
}

function signOut() {
  localStorage.removeItem('qa_auth');
  location.reload();
}

function pill(text, onClick) {
  const el = document.createElement('button');
  el.textContent = text;
  el.onclick = onClick;
  Object.assign(el.style, {
    position: 'fixed', left: '16px', bottom: '16px', zIndex: 9999,
    padding: '8px 14px', borderRadius: '999px', border: '1px solid var(--line)',
    background: 'var(--surface)', color: 'var(--ink-2)', font: '600 12.5px var(--font-ui)',
    boxShadow: 'var(--shadow-md)', cursor: 'pointer',
  });
  document.body.appendChild(el);
  return el;
}

function handleCredential(resp) {
  const c = decodeJwt(resp.credential);
  if (ALLOWED_DOMAIN && c.hd && c.hd !== ALLOWED_DOMAIN) {
    alert('Please sign in with your @' + ALLOWED_DOMAIN + ' account.');
    return;
  }
  localStorage.setItem('qa_auth', JSON.stringify({ name: c.name || '', email: c.email || '', token: resp.credential }));
  location.reload();
}

function init() {
  if (!CLIENT_ID) return; // sign-in disabled — manual-email fallback handles the auditor field

  const existing = readAuth();
  if (existing && existing.email) {
    pill('● ' + existing.email + '  ·  Sign out', signOut);
    return;
  }

  const s = document.createElement('script');
  s.src = 'https://accounts.google.com/gsi/client';
  s.async = true; s.defer = true;
  s.onload = () => {
    if (!window.google || !window.google.accounts) return;
    window.google.accounts.id.initialize({ client_id: CLIENT_ID, callback: handleCredential, hd: ALLOWED_DOMAIN });
    const host = document.createElement('div');
    Object.assign(host.style, { position: 'fixed', left: '16px', bottom: '16px', zIndex: 9999 });
    document.body.appendChild(host);
    window.google.accounts.id.renderButton(host, { theme: 'outline', size: 'medium', text: 'signin_with' });
    window.google.accounts.id.prompt(); // One Tap
  };
  document.head.appendChild(s);
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
else init();
