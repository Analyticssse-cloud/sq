// employees.js  →  GET /api/employees
// Returns the EmployeeMaster tab as objects. Powers the LRM autocomplete + auto-fill.
const { readSheet, rowsToObjects, json } = require('./_sheets');

exports.handler = async () => {
  try {
    const rows = rowsToObjects(await readSheet('EmployeeMaster!A:H'));
    const emps = rows.map(r => ({
      name: r['LRM Name'], email: r['LRM Email'],
      tlName: r['TL Name'], tlEmail: r['TL Email'],
      mgrName: r['ZSM Name'], mgrEmail: r['ZSM Email'],
      adosName: r['ADOS Name'], adosEmail: r['ADOS Email'],
    })).filter(e => e.name);
    return json(200, emps);
  } catch (e) {
    return json(500, { error: String(e && e.message || e) });
  }
};
