// meetings.js  →  GET /api/meetings
// Returns the "meeting tracker" tab as objects — the master list of every scheduled
// meeting. Powers the New Audit lead picker (pending = tracker minus audited) and the
// City & TL Summary (Total MS / Pending / coverage).
//
// Each row is joined to EmployeeMaster by assigned_lrm_email so we can resolve the LRM's
// Team Lead. Per the agreed model, THE TEAM LEAD IS THE AUDITOR — so a meeting's assigned
// auditor is its LRM's TL, and a TL's "My queue" is simply their own team's meetings.
//
// Expected tab name: "meeting tracker"  (columns, in order):
//   lead_id | meeting_type | Combined City, Cluster | meeting_schedule_date
//   | assigned_lrm_email | assigned_lrm
const { readSheet, rowsToObjects, json } = require('./_sheets');

// "June 9, 2026, 8:30 AM" (or an ISO string) -> "2026-06-09", using local parts to avoid
// any UTC date-shift. Returns '' if unparseable.
function toISODate(raw) {
  if (!raw) return '';
  const s = String(raw).trim();
  // already ISO-ish
  const m = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (m) return m[1] + '-' + m[2] + '-' + m[3];
  const d = new Date(s);
  if (isNaN(d.getTime())) return '';
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

// Pull the "Combined City, Cluster" value into a {city, cluster} pair. The value may be a
// bare city ("Nagpur"), "City, Cluster", or "City - Cluster".
function splitCityCluster(v) {
  const s = String(v || '').trim();
  if (!s) return { city: 'Unassigned', cluster: '—' };
  let parts = null;
  if (s.indexOf(',') >= 0) parts = s.split(',');
  else if (s.indexOf(' - ') >= 0) parts = s.split(' - ');
  else if (s.indexOf('-') >= 0) parts = s.split('-');
  if (parts && parts.length > 1) {
    const city = parts[0].trim();
    return { city, cluster: parts.slice(1).join(' ').trim() ? city + ' · ' + parts.slice(1).join(' ').trim() : city };
  }
  return { city: s, cluster: s };
}

// tolerant header lookup (handles the literal comma in "Combined City, Cluster")
function pick(row, keys) {
  for (const k of keys) {
    for (const rk of Object.keys(row)) {
      if (rk.trim().toLowerCase() === k.trim().toLowerCase()) return row[rk];
    }
  }
  return '';
}

exports.handler = async () => {
  try {
    // 1) LRM email -> Team Lead (the auditor)
    const emps = rowsToObjects(await readSheet('EmployeeMaster!A:H'));
    const norm = s => String(s || '').trim().toLowerCase();
    const tlByLrm = {};
    emps.forEach(e => {
      const em = norm(e['LRM Email']);
      if (em) tlByLrm[em] = { tlName: e['TL Name'] || '', tlEmail: e['TL Email'] || '' };
    });

    // 2) the meeting tracker rows
    const rows = rowsToObjects(await readSheet("'meeting tracker'!A:F"));
    const meetings = rows.map(r => {
      const leadId = pick(r, ['lead_id', 'leadid', 'lead id']);
      if (!leadId) return null;
      const lrmEmail = pick(r, ['assigned_lrm_email', 'assigned lrm email', 'lrm email']);
      const { city, cluster } = splitCityCluster(pick(r, ['Combined City, Cluster', 'combined city cluster', 'city', 'combined city']));
      const sched = pick(r, ['meeting_schedule_date', 'meeting schedule date', 'meeting scheduled date']);
      const tl = tlByLrm[norm(lrmEmail)] || { tlName: '', tlEmail: '' };
      return {
        leadId: String(leadId).trim(),
        meetingType: pick(r, ['meeting_type', 'meeting type']) || 'fresh_meeting',
        city, cluster,
        scheduleDate: String(sched || ''),
        scheduleISO: toISODate(sched),
        lrmEmail: String(lrmEmail || '').trim(),
        lrmName: pick(r, ['assigned_lrm', 'assigned lrm', 'lrm name']) || '',
        // Team Lead is the auditor:
        assignedAuditorEmail: tl.tlEmail,
        assignedAuditorName: tl.tlName,
      };
    }).filter(Boolean);

    return json(200, meetings);
  } catch (e) {
    return json(500, { error: String(e && e.message || e) });
  }
};
